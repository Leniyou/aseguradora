<?php
// Para saber si se ha iniciado sesion//

//session_start();

//if (isset($_SESSION['empleado_nap'])) {

	// archivo con la conexion a la DB//

	require_once dirname(__FILE__) . '/php/Conexion_DB.php';

	// function query() para el select de el tipo de vehiculo //
	$tipo_vehiculo = "SELECT * FROM vehiculo_tipo ORDER BY vehiculo ASC";
	$tipo_veh = mysqli_query($link, $tipo_vehiculo);
	
	// function query() para el select de las marcas del vehiculo //
	$marca_vehiculo = "SELECT * FROM vehiculo_marca ORDER BY marca ASC";
	$marca_veh = mysqli_query($link, $marca_vehiculo);
	
	// function query() para el select de las partes//
	$partes = "SELECT * FROM partes ORDER BY parte ASC";
	$query_partes = mysqli_query($link, $partes);
	
	// Cierra la conexion a la DB//
	mysqli_close($link);
//}
/*else {
	header('location: Login.php');
}
*/
?>

<!DOCTYPE html>
<!-- saved from url=(0063)https://fs29.formsite.com/M1zm2M/form1/index.html?1517190425322 -->
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <base href=".">
    <meta http-equiv="cache-control" content="no-cache">
    <meta http-equiv="expires" content="0">
    <meta property="og:title" content="Levantamiento">
    <meta property="og:type" content="website">
    <meta property="og:url" content="https://qsgsolutions.com">
    <meta property="og:site_name" content="https://qsgsolutions.com">
    <meta property="og:description" content="Levantamiento de Daños">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link rel="shortcut icon" href="assets/icon.png" type="image/x-icon" />
    <title>Levantamiento de Daños</title>
    
    <link rel="stylesheet" type="text/css" media="screen" href="jQueryAssets/jquery-ui.min.css">
    <link rel="stylesheet" type="text/css" media="all" href="css/fonts7.css">
    <link rel="stylesheet" type="text/css" media="all" href="css/screen7.css">
    <link rel="stylesheet" type="text/css" media="screen" href="css/responsive7.css">
    <link rel="stylesheet" type="text/css" href="css/menu.css"> 
    <link rel="stylesheet" type="text/css" href="css/template.css">
    <link rel="stylesheet" type="text/css" href="css/extras.css">
    
    <script type="text/javascript" src="jQueryAssets/jquery-3.3.1.min.js"></script>
	<script type="text/javascript" src="jQueryAssets/jquery-ui.js"></script>
    <script type="text/javascript" src="jQueryAssets/jquery-ui.min.js"></script>
    <script type="text/javascript" src="js/form7.js"></script>
    
    <!-- popup con instrucciones -->
    <script type="text/javascript">
        var instructions = {};
        instructions[10] = "Seleccione el tipo de vehiculo. Agricola, Autobus, Carro, etc...";
        instructions[11] = "Seleccione la marca del vehiculo. Honda, Toyota, etc...";
        instructions[12] = "Escribe el modelo del Vehículo.";
        instructions[13] = "Número de chasis del vehículo.";
        instructions[14] = "Seleccione el tipo de cliente. Normal o Corporativo.";
        instructions[15] = "Nombre del Proveedor";
        instructions[16] = "Nombre del taller.";
        instructions[17] = "Seleccione el tipo de corredor. Corredor 1 o Corredor 2.";
        instructions[18] = "Seleccione la parte afectada. Motor, Frenos, Transmisión, etc...";
        instructions[19] = "Seleccione la pieza afectada. Bujía, Cigueñal, etc...";
        instructions[20] = "Seleccione la acción a realizar. Cambio o Reparación.";
        instructions[21] = "Estado de la pieza a cambiar o reemplazar.";
        instructions[22] = "Cantidad de piezas a cambiar o reemplazar.";
        instructions[23] = "Añade alguna nota adicional.";
    </script>
    
    <!-- menu -->
    <script type="text/javascript">
		$(document).ready(function(){
			$('.menu-tab').click(function(){
				$('.menu-hide').toggleClass('show');
				$('.menu-tab').toggleClass('active');
		  	});
		  	$('a').click(function(){
				$('.menu-hide').removeClass('show');
				$('.menu-tab').removeClass('active');
		  	});
		});
	</script>
    
    <!-- Carga la pieza dependiendo de la parte afectada -->
    <script>
	$(document).ready(function() {
		$("select[name='parte[]']").click(function() {
			var parte = '#' + $(this).attr('id');
			var num = parte.split(/(\d+)/);
			var pieza = '#pieza' + num[1];
			var accion = '#accion' + num[1];
			var estado = '#estado' + num[1];
			
			$(parte).change(function() {
				var parte = $(this).val();
				var dataString = 'parte=' + parte;
										
				$.ajax({
					type: "POST",
					url: "php/cargar_pieza.php",
					data: dataString,
					cache: false,
					success: function(html) {
						$(pieza).html(html);
					}
				});
       		});	
			
			$(accion).change(function() {
				var accions = $(this).val();
				var dataString = 'accion=' + accions;
						
				$.ajax({
					type: "POST",
					url: "php/cargar_estado_pieza.php",
					data: dataString,
					cache: false,
					success: function(html) {
						$(estado).html(html);
					}
				});
       		});
       	}); 
	});
	</script>
    
    <!-- Agrega mas campos -->
    <script>
		var counter = 2;
		var limit = 12;
		
		// Funcion para agregar los campos extras //	
		function addInputs(divName){
			
			if (counter == limit) {
				alert("Solo puedes agregar " + counter + " registros a la vez");
			 } else {
				 
			 	var newdiv = document.createElement('div');
				
				var dataString = 'contador=' + counter;
				
				$.ajax({
					type:"POST",
					url: "php/cargar_campos.php",
					data: dataString,
					cache: false,
					success: function(html) {
						$(newdiv).html(html);
					}
				});
				
				counter += 1;
				newdiv.setAttribute('id','row' + counter);   
				document.getElementById(divName).appendChild(newdiv);
				
				// cuenta la cantidad de campos agregados //
				var contador = document.getElementById('contador').value;
				contador++;
				document.getElementById('contador').setAttribute('value', contador);
				
				
				if (contador > 2) {
					$('#quitar').show();
				}
			 }
		}
		
		// Funcion para borrar los campos extras //
		function delInput(){
			
			if (counter == 2){
				alert("No existen campos extras para eliminarlos");	
			} 
			else {
				var div = document.getElementById("row" + counter);
				
				div.outerHTML = "";
				
				delete div;
						
				counter = counter - 1;
				
				if (counter <= 2) {
					$('#quitar').hide();
				}
			}
		}
			
	</script>
   
</head>

<body>
    <form method="post" id="FSForm" action="php/levantamiento.php" enctype="application/x-www-form-urlencoded" onsubmit="">
              
    	<!-- MENU -->
        <div class="menu-tab">
        	<div id="one"></div>
        	<div id="two"></div>
        	<div id="three"></div>
             <p>MENU</p>
    	</div>
        <div class="menu-hide">
          <nav>
            <ul>
              <li class="activa"><a href="#">Levantamiento</a></li>
              <li><a href="reclamaciones.php">Reclamaciones</a></li>
              <li><a href="requisiciones.php">Requisiciones</a></li>
              <li><a href="#">Presupuesto</a></li>
              <li><a href="#">Aprobación Presupuesto</a></li>
            </ul>
          </nav>
        </div>

        <!-- BEGIN_ITEMS -->
        
        <div class="form_table">

            <div class="clear"></div>

            <div id="q69" class="q full_width">
                <a class="item_anchor" name="ItemAnchor0"></a>
                <div class="segment_header" id="header">
                    <h1 id="formh1" style="font-family:&#39;Cinzel&#39;,serif;">Formulario de daños</h1>
                </div>
            </div>

            <div class="clear"></div>

            <div id="q1" class="q full_width">
                <a class="item_anchor" name="ItemAnchor1"></a>
                <div class="full_width_space">
                    <div class="centrar"><span style="font-size: 20px;"><strong>Levantamiento de Daños</strong></span></div>
                    <div class="centrar"><span style="font-size: 16px;">Formulario de Levantamiento de Daños</span></div>
                </div>
            </div>

            <div class="clear"></div>

            <div id="q2" class="q full_width">
                <a class="item_anchor" name="ItemAnchor2"></a>
                <div class="segment_header" style="width:auto;text-align:Center;">
                    <h1 style="font-weight:bold;font-size:18px;padding:20px 1em;">DATOS GENERALES DEL VEHICULO</h1>
                </div>
            </div>

            <div class="clear"></div>

            <div id="q128" class="q full_width">
                <a class="item_anchor" name="ItemAnchor3"></a>
                <br>
            </div>

            <div class="clear"></div>
            
			<!-- tipo -->
            <div id="q10" class="q required">
                <a class="item_anchor" name="ItemAnchor4"></a>
                <label class="question top_question" for="tipo">Tipo&nbsp;<b class="icon_required" style="color:#FF0000">*</b>&nbsp;<img class="svg popup_button instructions" src="svg/qbut.svg" alt="instrucciones"></label>
                <select id="tipo" name="tipo" class="drop_down" style="width:202px;" required>
					<option value="" selected>Tipo de Vehiculo</option>
                    <?php while($tipo = mysqli_fetch_array($tipo_veh)){ 
                    	echo '<option value="'.$tipo['vehiculo']. '">'.$tipo['vehiculo']. '</option>'; } ?>
             	</select>
            </div>
            
            <!-- marca -->
            <div id="q11" class="q required">
                <a class="item_anchor" name="ItemAnchor5"></a>
                <label class="question top_question" for="RESULT_RadioButton-5">Marca&nbsp;<b class="icon_required" style="color:#FF0000">*</b>&nbsp;<img class="svg popup_button instructions" src="svg/qbut.svg" alt="instrucciones"></label>
                <select id="marca" name="marca" class="drop_down" style="width:202px;" required>
                    <option value="" selected>Marca del Vehiculo</option>
                    <?php while($marca = mysqli_fetch_array($marca_veh)){ 
                      echo '<option value="'.$marca['marca']. '">'.$marca['marca']. '</option>'; } ?>
				</select>
            </div>
            
            <!-- modelo -->
            <div id="q12" class="q required">
                <a class="item_anchor" name="ItemAnchor6"></a>
                <label class="question top_question" for="modelo">Modelo&nbsp;<b class="icon_required" style="color:#FF0000">*</b>&nbsp;<img class="svg popup_button instructions" src="svg/qbut.svg" alt="instrucciones"></label>
                <input type="text" name="modelo" class="text_field" id="modelo" placeholder="Modelo del Vehículo" maxlength="255" value="" style="width:202px;" required>
            </div>
            
            <!-- chasis -->
            <div id="q13" class="q required">
                <a class="item_anchor" name="ItemAnchor7"></a>
                <label class="question top_question" for="chasis">No. Chasis&nbsp;<b class="icon_required" style="color:#FF0000">*</b>&nbsp;<img class="svg popup_button instructions" src="svg/qbut.svg" alt="instrucciones"></label>
                <input type="text" name="chasis" class="text_field number_field" id="chasis" placeholder="Número de Chasis" size="20" maxlength="255" value="" style="width:202px;" required>
            </div>
            
            <!-- cliente -->
            <div id="q14" class="q required">
                <a class="item_anchor" name="ItemAnchor8"></a>
                <label class="question top_question" for="cliente">Cliente&nbsp;<b class="icon_required" style="color:#FF0000">*</b>&nbsp;<img class="svg popup_button instructions" src="svg/qbut.svg" alt="instrucciones"></label>
                <select id="cliente" name="cliente" class="drop_down" style="width:202px;" required>
                    <option value="" selected="selected">Tipo de cliente</option>
                    <option value="Normal">Normal</option>
                    <option value="Corporativo">Corporativo</option>
				</select>
            </div>
            
            <!-- proveedor -->
            <div id="q15" class="q required">
                <a class="item_anchor" name="ItemAnchor9"></a>
                <label class="question top_question" for="proveedor">Proveedor&nbsp;<b class="icon_required" style="color:#FF0000">*</b>&nbsp;<img class="svg popup_button instructions" src="svg/qbut.svg" alt="instrucciones"></label>
                <input type="text" name="proveedor" class="text_field" id="proveedor" placeholder="Nombre del Proveedor" maxlength="255" value="" style="width:180px;" required>
            </div>
            
            <!-- taller -->
            <div id="q16" class="q required">
                <a class="item_anchor" name="ItemAnchor10"></a>
                <label class="question top_question" for="taller">Taller&nbsp;<b class="icon_required" style="color:#FF0000">*</b>&nbsp;<img class="svg popup_button instructions" src="svg/qbut.svg" alt="instrucciones"></label>
                <input type="text" name="taller" class="text_field" id="taller" placeholder="Nombre del Taller" maxlength="255" value="" style="width:202px;" required>
            </div>
            
            <!-- corredor -->
            <div id="q17" class="q required">
                <a class="item_anchor" name="ItemAnchor11"></a>
                <label class="question top_question" for="RESULT_RadioButton-11">Corredor&nbsp;<b class="icon_required" style="color:#FF0000">*</b>&nbsp;<img class="svg popup_button instructions" src="svg/qbut.svg" alt="instrucciones"></label>
                <select id="corredor" name="corredor" class="drop_down" style="width:221px;" required>
                    <option value="" selected="selected">Tipo corredor</option>
                    <option value="Corredor 1">Corredor 1</option>
                    <option value="Corredor 2">Corredor 2</option>
            	</select>
            </div>

            <div class="clear"></div>

            <div id="q127" class="q full_width">
                <a class="item_anchor" name="ItemAnchor12"></a>
                <br>
            </div>

            <div class="clear"></div>

            <div id="q118" class="q full_width">
                <a class="item_anchor" name="ItemAnchor13"></a>
                <div class="segment_header" style="width:auto;text-align:Center;">
                    <h1 style="font-weight:bold;font-size:18px;padding:20px 1em;">DAÑOS OCURRIDOS AL VEHICULO</h1>
                </div>
            </div>

            <div class="clear"></div>

            <div id="q129" class="q full_width">
                <a class="item_anchor" name="ItemAnchor14"></a>
                <br>
            </div>

            <div class="clear"></div>
            
            <!-- parte -->
            <div id="q18" class="q required">
                <a class="item_anchor" name="ItemAnchor15"></a>
                <label class="question top_question" for="parte">Parte&nbsp;<b class="icon_required" style="color:#FF0000">*</b>&nbsp;<img class="svg popup_button instructions" src="svg/qbut.svg" alt="instrucciones"></label>
                <select id="parte1" name="parte[]" class="drop_down" style="width:175px;" required>
                    <option value="" selected>Parte afectada</option>
                    <?php while($parte = mysqli_fetch_array($query_partes)){ 
                    	echo '<option value="'.$parte['parte'].'">'.$parte['parte']. '</option>'; } ?>
				</select>
            </div>
            
            <!-- pieza -->
            <div id="q19" class="q required">
                <a class="item_anchor" name="ItemAnchor16"></a>
                <label class="question top_question" for="pieza">Pieza&nbsp;<b class="icon_required" style="color:#FF0000">*</b>&nbsp;<img class="svg popup_button instructions" src="svg/qbut.svg" alt="instrucciones"></label>
                <select id="pieza1" name="pieza[]" class="drop_down" style="width:175px;" required>
                    <option value="" selected="selected">Pieza afectada</option>
            	</select>
            </div>
            
            <!-- accion -->
            <div id="q20" class="q required">
                <a class="item_anchor" name="ItemAnchor17"></a>
                <label class="question top_question" for="accion">Acción&nbsp;<b class="icon_required" style="color:#FF0000">*</b>&nbsp;<img class="svg popup_button instructions" src="svg/qbut.svg" alt="instrucciones"></label>
                <select id="accion1" name="accion[]" class="drop_down" style="width:175px;" required>
                    <option value="" selected="selected">Acción a realizar</option>
                    <option value="Cambio">Cambio</option>
                    <option value="Reparación">Reparación</option>
				</select>
            </div>
            
            <!-- estado -->
            <div id="q21" class="q required">
                <a class="item_anchor" name="ItemAnchor18"></a>
                <label class="question top_question" for="estado">Estado&nbsp;<b class="icon_required" style="color:#FF0000">*</b>&nbsp;<img class="svg popup_button instructions" src="svg/qbut.svg" alt="instrucciones"></label>
                <select id="estado1" name="estado[]" class="drop_down" style="width:175px;" required>
                    <option value="" selected="selected">Estado de la pieza</option>
				</select>
            </div>
            
            <!-- cantidad -->
            <div id="q22" class="q required">
                <a class="item_anchor" name="ItemAnchor19"></a>
                <label class="question top_question" for="cantidad">Cantidad&nbsp;<b class="icon_required" style="color:#FF0000">*</b>&nbsp;<img class="svg popup_button instructions" src="svg/qbut.svg" alt="instrucciones"></label>
                <input type="text" name="cantidad[]" class="text_field number_field" id="cantidad" placeholder="Cantidad" maxlength="255" value="" style="width:100px;" required>
            </div>
            
            <hr width="1100px">

            <div class="clear"></div>
            
            <!-- Se cargan los campos agregados -->
            <div class="fsRow fsFieldRow" id="campos"></div>
            
            <!-- Contador de la cantidad de campos -->
            <input type="hidden" id="contador" name="contador" value="2"/>
            
            <div class="outside_container">
            	<div class="buttons_reverse">
                	
                    <!-- Quitar Campos -->
                   	<input id="quitar" type="button" value="Quitar Campos" name="quitar" onClick="delInput();" style="display:none">
                    
                	<!-- Agregar Campos -->
                	<input id="agregar" type="button" value="Agregar Campos" name="agregar" onClick="addInputs('campos');" >
                    
                </div>
        	</div>
                       
            <div class="clear"></div>
            
        	<div class="outside_container">
            	<div class="buttons_reverse"><input type="submit" name="registrar" value="Guardar Formulario" class="submit_button" id="FSsubmit"></div>
        	</div>
         
        </div>
        <!-- END_ITEMS -->
    </form>

</body>

</html>