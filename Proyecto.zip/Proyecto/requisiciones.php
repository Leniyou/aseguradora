<?php
// Para saber si se ha iniciado sesion//

//session_start();

//if (isset($_SESSION['empleado_nap'])) {

	// archivo con la conexion a la DB//
	require_once dirname(__FILE__) . '/php/Conexion_DB.php';

	// function query() para el select de los reportes //
	$requisicion = "SELECT id_requisicion, num_requisicion, num_reclamacion, tipo, marca, modelo, chasis, cliente, proveedor, taller, corredor, UNIX_TIMESTAMP(CONVERT_TZ(fecha, '+00:00', @@global.time_zone))*1 as fecha FROM requisiciones GROUP BY num_requisicion DESC";
	$query = mysqli_query($link, $requisicion);
				
	// Cierra la conexion a la DB //
	mysqli_close($link);
//}
/*else {
	header('location: Login.php');
}
*/
?>

<!DOCTYPE html>
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <base href=".">
    <meta http-equiv="cache-control" content="no-cache">
    <meta http-equiv="expires" content="0">
    <meta property="og:title" content="Reclamaciones">
    <meta property="og:type" content="https://qsgsolutions.com">
    <meta property="og:url" content="https://qsgsolutions.com">
    <meta property="og:site_name" content="Reclamaciones">
    <meta property="og:description" content="Buscar Reclamaciones">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link rel="shortcut icon" href="assets/icon.png" type="image/x-icon" />
    <title>Requisiciones</title>
    
    <link rel="stylesheet" type="text/css" href="DataTables/datatables.min.css">
    <link rel="stylesheet" type="text/css" href="jQueryAssets/jquery-ui/jquery-ui.min.css">
    <link rel="stylesheet" type="text/css" href="jQueryAssets/jquery-ui/themes/redmond/theme.css">
    <link rel="stylesheet" type="text/css" href="DataTables/Responsive-2.2.1/css/responsive.jqueryui.min.css">
    <link rel="stylesheet" type="text/css" href="DataTables/FixedHeader-3.1.3/css/fixedHeader.jqueryui.min.css">
    
    <link rel="stylesheet" type="text/css" href="css/template.css">
    <link rel="stylesheet" type="text/css" media="all" href="css/fonts7.css">
    <link rel="stylesheet" type="text/css" media="all" href="css/screen7.css">
	<link rel="stylesheet" type="text/css" href="css/menu.css">
    <link rel="stylesheet" type="text/css" media="screen" href="css/responsive7.css">
    
	<script src="jQueryAssets/jquery-3.3.1.min.js"></script>
    <script src="jQueryAssets/jquery-ui.min.js"></script>
    <script src="DataTables/datatables.min.js"></script>
    <script src="DataTables/Responsive-2.2.1/js/responsive.jqueryui.min.js"></script>
    <script src="DataTables/FixedHeader-3.1.3/js/dataTables.fixedHeader.min.js"></script>
    <script src="js/moment.min.js"></script>
	<script src="js/datetime-moment.js"></script>
    
    <!-- menu -->
    <script type="text/javascript">
		$(document).ready(function(){
			$('.menu-tab').click(function(){
				$('.menu-hide').toggleClass('show');
				$('.menu-tab').toggleClass('active');
		  	});
		  	$('a').click(function(){
				$('.menu-hide').removeClass('show');
				$('.menu-tab').removeClass('active');
		  	});
		});
	</script>
      
</head>

<body>
	<!-- MENU -->
    <div class="menu-tab">
    	<div id="one"></div>
        <div id="two"></div>
        <div id="three"></div>
        <p>MENU</p>
    </div>
    <div class="menu-hide">
    	<nav>
        	<ul>
            	<li><a href="levantamiento.php">Levantamiento</a></li>
              	<li><a href="reclamaciones.php">Reclamaciones</a></li>
              	<li class="activa"><a href="#">Requisiciones</a></li>
              	<li><a href="#">Presupuesto</a></li>
              	<li><a href="#">Aprobación Presupuesto</a></li>
            </ul>
       	</nav>
 	</div>

	<!-- BEGIN_ITEMS -->
        
    <div class="form_table" style="width:90%">

		<div class="clear"></div>

            <div id="q69" class="q full_width">
                <a class="item_anchor" name="ItemAnchor0"></a>
                <div class="segment_header" style="color:#FFFFFF;width:auto;text-align:Center;background-repeat:repeat;background-color:transparent;background-size: cover;background-position: 50% 50%;">
                    <h1 style="font-weight:bold;font-size:24px;font-family:&#39;Cinzel&#39;,serif;padding:20px 1em ;background-color:hsla(0,0%,50%,1.00);">Requisiciones</h1>
                </div>
            </div>

            <div id="q128" class="q full_width">
                <a class="item_anchor" name="ItemAnchor3"></a>
                <br>
            </div>
            
           	<div class="clear"></div>

            <div id="q1" class="q full_width">
                <a class="item_anchor" name="ItemAnchor1"></a>
                <div class="full_width_space">
                    <div style="text-align: center;"><span style="font-size: 20px;"><strong>Requisiciones Activas</strong></span></div>
                    <div style="text-align: center;"><span style="font-size: 16px;">Busqueda de Requisiciones Activas</span></div>
                </div>
            </div>

            <div class="clear"></div>
            
            <div id="q128" class="q full_width">
                <a class="item_anchor" name="ItemAnchor3"></a>
                <br>
            </div>

            <div class="clear"></div>

			<!-- tabla -->
            <table id="tabla" class="display"> <!-- tabla encabezado -->
            	<thead>
                	<tr>
                    	<th style="text-align:center">No. Requisicion</th>
                    	<th style="text-align:center">No. Reclamación</th>
                        <th style="text-align:center">Tipo</th>
                        <th style="text-align:center">Marca</th>
                        <th style="text-align:center">Modelo</th>
                        <th style="text-align:center">Chasis</th>
                        <th style="text-align:center">Cliente</th>
                        <th style="text-align:center">Proveedor</th>
                        <th style="text-align:center">Taller</th>
                        <th style="text-align:center">Corredor</th>
                        <th style="text-align:center">Fecha</th>
                        <th style="text-align:center">Tiempo</th>
                     </tr>
              	</thead>
                <tbody>
				<?php
                error_reporting(E_ALL);
                
                // funcion que calcula el intervalo de tiempo (fecha registrada contra fecha actual) //
                class MyDateInterval extends DateInterval {
                    public
                        $pluralCheck = '()',
                            // Must be exactly 2 characters long
                            // The first character is the opening brace, the second the closing brace
                            // Text between these braces will be used if > 1, or replaced with $this->singularReplacement if = 1
                        $singularReplacement = '',
                            // Replaces $this->pluralCheck if = 1
                            // hour(s) -> hour
                        $separator = ', ',
                            // Delimiter between units
                            // 3 hours, 2 minutes
                        $finalSeparator = ', ',
                            // Delimeter between next-to-last unit and last unit
                            // 3 hours, 2 minutes, and 1 second
                        $finalSeparator2 = ', ';
                            // Delimeter between units if there are only 2 units
                            // 3 hours and 2 minutes
                
                    public static function createFromDateInterval (DateInterval $interval) {
                        $obj = new self('PT0S');
                        foreach ($interval as $property => $value) {
                            $obj->$property = $value;
                        }
                        return $obj;
                    }
                
                    public function formatWithoutZeroes () {
                        // Each argument may have only one % parameter
                        // Result does not handle %R or %r -- but you can retrieve that information using $this->format('%R') and using your own logic
                        $parts = array ();
                        foreach (func_get_args() as $arg) {
                            $pre = mb_substr($arg, 0, mb_strpos($arg, '%'));
                            $param = mb_substr($arg, mb_strpos($arg, '%'), 2);
                            $post = mb_substr($arg, mb_strpos($arg, $param)+mb_strlen($param));
                            $num = intval(parent::format($param));
                
                            $open = preg_quote($this->pluralCheck[0], '/');
                            $close = preg_quote($this->pluralCheck[1], '/');
                            $pattern = "/$open(.*)$close/";
                            list ($pre, $post) = preg_replace($pattern, $num == 1 ? $this->singularReplacement : '$1', array ($pre, $post));
                
                            if ($num != 0) {
                                $parts[] = $pre.$num.$post;
                            }
                        }
                
                        $output = '';
                        $l = count($parts);
                        foreach ($parts as $i => $part) {
                            $output .= $part.($i < $l-2 ? $this->separator : ($l == 2 ? $this->finalSeparator2 : ($i == $l-2 ? $this->finalSeparator : '')));
                        }
                        return $output;
                    }
                }
                
                // Especifica la Zona horaria //
                date_default_timezone_set( "America/Santo_Domingo");
                
                // la fecha y la hora actuales //				
                $ahora = new DateTime();
                
                // desde aqui se cargan los campos de la base de datos //					
                while ($row = mysqli_fetch_array($query)){
                    
                /* TimeStamp de los campos cargados desde la base de datos tambien usamos 
                    este campo para odernar los registros del mas nuevo al mas viejo */				
                    $tsFecha = date('g:iA d/m/Y', $row['fecha']);
                    
                    // Convertimos la fecha a tipo DateTime para poder comparar con el interval //
                    $fecha = DateTime::createFromFormat('g:iA d/m/Y', $tsFecha);
                                            
                    /* Tiempo que tiene abierta la reclamacion, este campo hace la comparacion entre
                    la fecha de entrada del registro y la fecha actual */
                    $tiempo = MyDateInterval::createFromDateInterval($ahora->diff($fecha));
                    
                    echo "<tr>";
                        
                        // no requisicion //
							echo "<td style='text-align:center'><a href='requisicion.php?num_requisicion=".$row['num_requisicion']."' target='_blank'>".$row['num_requisicion']."</a></td>";
	
							// no reclamacion //
							echo "<td style='text-align:center'>".$row['num_reclamacion']."</td>";
							
							// tipo //
							echo "<td style='text-align:center'>".$row['tipo']."</td>";
				
							// marca //
							echo "<td style='text-align:center'>".$row['marca']."</td>";
							
							// modelo //
							echo "<td style='text-align:center'>".$row['modelo']."</td>";
							
							// chasis //
							echo "<td style='text-align:center'>".$row['chasis']."</td>";
							
							// cliente //
							echo "<td style='text-align:center'>".$row['cliente']."</td>";
							
							// proveedor //
							echo "<td style='text-align:center' class='letra'>".$row['proveedor']."</td>";
								
							// taller //
							echo "<td style='text-align:center' class='letra'>".$row['taller']."</td>";
							
							// corredor //
							echo "<td style='text-align:center'>".$row['corredor']."</td>";
							
							// fecha //
							echo "<td style='text-align:center;'>".$tsFecha."</td>";
							
							// tiempo //
							echo "<td style='text-align:center'>".$tiempo->formatWithoutZeroes('%m mes(es)', '%d día(s)', '%h hr(s)', '%i min(s)')."</td>";
							    
                    echo "</tr>";
                }
                ?>
        		</tbody>
        	</table>
        
        	<script>
			// Iniciacion del plugin DataTables que estiliza la tabla //
				$(document).ready(function() {
					$.fn.dataTable.moment( 'h:mma' );
					$.fn.dataTable.moment( 'LT' );
    				$.fn.dataTable.moment( 'DD, MM, YY' );
					$.fn.dataTable.moment( 'DD/MM/YYYY' );
					$.fn.dataTable.moment( 'h:mmA D/MM/YYYY' );
                	var table = $('#tabla').DataTable({
						fixedHeader: true,
						responsive: true,
						lengthChange: false,
						lengthMenu: [
                        	[10, 25, 50, -1],
                            ['10 registros', '25 registros', '50 registros', 'Todos']
                         ],
                         buttons: ['pageLength'],
						"order": [[ 10, "desc" ]]
                    });
                   table.buttons().container()
                   .insertBefore('#tabla_filter');
               });
			</script>
            
            <div class="clear"></div>
        </div>
        <!-- END_ITEMS -->
</body>

</html>