<?php
/*
	//Para saber si se ha iniciado sesion//
	session_start();
	
	if(isset($_SESSION['empleado_nap'])){ */
	
	//archivo con la conexion a la DB//
	include('Conexion_DB.php');
		
		if(($_POST['accion'])) {
			$accion = $_POST['accion'];
			
			$db_estado = "SELECT * FROM estado_pieza WHERE accion='$accion'";
			$query_estado = mysqli_query($link, $db_estado);
						
			echo  '<option value="" selected>Estado de la pieza...</option>';
			
			while ($row = mysqli_fetch_array($query_estado)) {
				$estado = $row['estado'];
								
				echo '<option value="'.$estado.'">'.$estado.'</option>';
                
			}
				
		//Cierra la conexion a la DB//
		mysqli_close($link);
	
	}
	/*
	else {
		header('location: ../Login.php');	
	}
	*/
?>