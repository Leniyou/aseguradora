<?php
/*
	//Para saber si se ha iniciado sesion//
	session_start();
	
	if(isset($_SESSION['empleado_nap'])){ */
	
	//archivo con la conexion a la DB//
	include('Conexion_DB.php');
			
	$db_parte = "SELECT * FROM partes ORDER BY parte ASC";
	$query_parte = mysqli_query($link, $db_parte);
	
	$contador = $_POST['contador'];
	
	echo "<div class='clear'></div>
		<div id='q129' class='q full_width'>
			<a class='item_anchor' name='ItemAnchor14'></a>
			<br>
		</div>
		<div class='clear'></div>";
	
	echo '<!-- parte -->
            <div id="q18" class="q required">
                <a class="item_anchor" name="ItemAnchor15"></a>
                <label class="question top_question" for="parte">Parte&nbsp;<b class="icon_required" style="color:#FF0000">*</b>&nbsp;<img class="svg popup_button instructions" src="svg/qbut.svg" alt="instrucciones"></label>
                <select id="parte'.$contador.'" name="parte[]" class="drop_down" style="width:175px;" required>
                    <option value="" selected>Parte afectada</option>';
                    while($parte = mysqli_fetch_array($query_parte)){ 
                    	echo '<option value="'.$parte['parte'].'">'.$parte['parte']. '</option>'; 
					}
			echo' </select>
            </div>';
			
	echo '<!-- pieza -->
            <div id="q19" class="q required">
                <a class="item_anchor" name="ItemAnchor16"></a>
                <label class="question top_question" for="pieza">Pieza&nbsp;<b class="icon_required" style="color:#FF0000">*</b>&nbsp;<img class="svg popup_button instructions" src="svg/qbut.svg" alt="instrucciones"></label>
                <select id="pieza'.$contador.'" name="pieza[]" class="drop_down" style="width:175px;" required>
                    <option value="" selected="selected">Pieza afectada</option>';
            echo '</select>
            </div>';
			
		echo '<!-- accion -->
            <div id="q20" class="q required">
                <a class="item_anchor" name="ItemAnchor17"></a>
                <label class="question top_question" for="accion">Acción&nbsp;<b class="icon_required" style="color:#FF0000">*</b>&nbsp;<img class="svg popup_button instructions" src="svg/qbut.svg" alt="instrucciones"></label>
                <select id="accion'.$contador.'" name="accion[]" class="drop_down" style="width:175px;" required>
                    <option value="" selected="selected">Acción a realizar</option>
                    <option value="Cambio">Cambio</option>
                    <option value="Reparación">Reparación</option>
				</select>
            </div>';

		echo '<!-- estado -->
            <div id="q21" class="q required">
                <a class="item_anchor" name="ItemAnchor18"></a>
                <label class="question top_question" for="estado">Estado&nbsp;<b class="icon_required" style="color:#FF0000">*</b>&nbsp;<img class="svg popup_button instructions" src="svg/qbut.svg" alt="instrucciones"></label>
                <select id="estado'.$contador.'" name="estado[]" class="drop_down" style="width:175px;" required>
                    <option value="" selected="selected">Estado de la pieza</option>
				</select>
            </div>';
	
		echo '<!-- cantidad -->
            <div id="q22" class="q required">
                <a class="item_anchor" name="ItemAnchor19"></a>
                <label class="question top_question" for="cantidad">Cantidad&nbsp;<b class="icon_required" style="color:#FF0000">*</b>&nbsp;<img class="svg popup_button instructions" src="svg/qbut.svg" alt="instrucciones"></label>
                <input type="text" name="cantidad[]" class="text_field number_field" id="cantidad'.$contador.'" placeholder="Cantidad" maxlength="255" value="" style="width:100px;" required>
            </div>';
				
		echo '<div class="clear"></div>
		<hr width="1100px">';
						
				
//Cierra la conexion a la DB//
mysqli_close($link);

?>
<!DOCTYPE html>
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>
<body>

<style>
hr {
    -moz-box-sizing: content-box;
    box-sizing: content-box;
    height: 0;
}
</style>

<!-- Carga la pieza dependiendo de la parte afectada 
    <script type="text/javascript">
	var val = "<?php //$counter = $_POST['counter']; echo $counter; ?>";
	var parte = '#parte' + val;
	var pieza = '#pieza' + val;
	var accion = '#accion' + val;
	var estado = '#estado' + val;
	
        $(document).ready(function() {
            $(parte).change(function() {
				var parte = $(this).val();
				var dataString = 'parte=' + parte;
						
				$.ajax({
					type: "POST",
					url: "php/cargar_pieza.php",
					data: dataString,
					cache: false,
					success: function(html) {
						$(pieza).html(html);
					}
				});
       		});	
			
			$(accion).change(function() {
				var accion = $(this).val();
				var dataString = 'accion=' + accion;
						
				$.ajax({
					type: "POST",
					url: "php/cargar_estado_pieza.php",
					data: dataString,
					cache: false,
					success: function(html) {
						$(estado).html(html);
					}
				});
       		});
				
        });
    </script> -->
    <!-- Carga la pieza dependiendo de la parte afectada -->
    <script>
	$(document).ready(function() {
		$("select[name='parte[]']").click(function() {
			var parte = '#' + $(this).attr('id');
			var num = parte.split(/(\d+)/);
			var pieza = '#pieza' + num[1];
			var accion = '#accion' + num[1];
			var estado = '#estado' + num[1];
			
			$(parte).change(function() {
				var parte = $(this).val();
				var dataString = 'parte=' + parte;
										
				$.ajax({
					type: "POST",
					url: "php/cargar_pieza.php",
					data: dataString,
					cache: false,
					success: function(html) {
						$(pieza).html(html);
					}
				});
       		});	
			
			$(accion).change(function() {
				var accions = $(this).val();
				var dataString = 'accion=' + accions;
						
				$.ajax({
					type: "POST",
					url: "php/cargar_estado_pieza.php",
					data: dataString,
					cache: false,
					success: function(html) {
						$(estado).html(html);
					}
				});
       		});
       	}); 
	});
	</script>
</body>
</html>