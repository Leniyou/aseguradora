<?php
/*
	//Para saber si se ha iniciado sesion//
	session_start();
	
	if(isset($_SESSION['empleado_nap'])){ */
	
	//archivo con la conexion a la DB//
	include('Conexion_DB.php');
		
	if(($_POST['parte'])) {
		$parte = $_POST['parte'];
			
		$db_parte = "SELECT * FROM partes WHERE parte='$parte'";
		$query_parte = mysqli_query($link, $db_parte);
			
		$db_pieza = "SELECT * FROM piezas WHERE parte='$parte' ORDER BY pieza ASC";
		$query_pieza = mysqli_query($link, $db_pieza);
			
		echo  '<option value="" selected>Pieza afectada...</option>';
			
		while ($row = mysqli_fetch_array($query_pieza)) {
			$pieza = $row['pieza'];
							
			echo '<option value="'.$pieza.'">'.$pieza.'</option>';
                
		}
				
		//Cierra la conexion a la DB//
		mysqli_close($link);
	
	}
	/*
	else {
		header('location: ../Login.php');	
	}
	*/
?>