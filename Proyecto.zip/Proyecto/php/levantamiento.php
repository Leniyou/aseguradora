<?php
	//Captura el nombre de quien ha iniciado sesion en el sistema//
	session_start();
	
	//archivo con la conexion a la DB//
	//include('Conexion_DB.php');
	include('Conexion_DB.php');
	
	//class Random que genera un numero de ticket aleatorio
	class Random {
	
		// random seed
		private static $RSeed = 0;
		
		// set seed
		public static function seed($s = 0) {
			self::$RSeed = abs(intval($s)) % 9999999 + 1;
			self::num();
		}
		
		// generate random number
		public static function num($min = 0, $max = 9999999) {
			if (self::$RSeed == 0) self::seed(mt_rand());
				self::$RSeed = (self::$RSeed * 125) % 2796203;
			return self::$RSeed % ($max - $min + 1) + $min;
		}	
	}
	
	$reclamacion = "SELECT num_reclamacion FROM reclamaciones";
	$sql = mysqli_query($link, $reclamacion);
	
	while($row = mysqli_fetch_array($sql)){
		$reclamacion = $row['num_reclamacion'];
	}
	
	//print_r($para);
	
	$num_reclamacion = "RCL".Random::num(00000, 10000);
	//echo $num_reclamacion;
	
	if ($num_reclamacion = $reclamacion) {
		$num_reclamacion = "RCL".Random::num(00000, 10000);
	}
	
	//if(isset($_SESSION['empleado_nap'])){
		
		if(isset($_POST['registrar'])) {	
			
			// Variables que guardan los datos que se llenaron en el form //	
			$tipo = mysqli_real_escape_string($link, $_POST['tipo']);
			$marca = mysqli_real_escape_string($link, $_POST['marca']);
			$modelo = mysqli_real_escape_string($link, $_POST['modelo']);
			$chasis = mysqli_real_escape_string($link, $_POST['chasis']);
			$cliente = mysqli_real_escape_string($link, $_POST['cliente']);
			$proveedor = mysqli_real_escape_string($link,$_POST['proveedor']);
			$taller = mysqli_real_escape_string($link, $_POST['taller']);
			$corredor = mysqli_real_escape_string($link, $_POST['corredor']);
			$contador = mysqli_real_escape_string ($link, $_POST['contador']);
			
			$contador = $contador - 1;
			
			$parte = $_POST['parte'];
			$pieza = $_POST['pieza'];
			$accion = $_POST['accion'];
			$estado = $_POST['estado'];
			$cantidad = $_POST['cantidad'];
			/*
			echo "contador= " .$contador. "<br/>";
			echo "modelo= " .$modelo. "<br/>";
			echo "chasis= " .$chasis. "<br/>";
			echo "proveedor= " .$proveedor. "<br/>";
			echo "taller= " .$taller. "<br/>";
			print_r($parte) . "=PARTE <br/>";
			print_r($pieza) . "=PIEZA<br/>";
			print_r($accion) . "=ACCION <br/>";
			print_r($estado) . "=ESTADO <br/>";
			print_r($cantidad) . "=CANTIDAD <br/>";
			echo "chasis " .$chasis. "<br/>";
			echo "proveedor " .$proveedor. "<br/>";
			echo "taller " .$taller. "<br/>";
			*/
			
			for ($i = 0; $i < $contador; $i++){
				
				$query = "INSERT INTO reclamaciones(num_reclamacion, tipo, marca, modelo, chasis, cliente, proveedor, taller, corredor, parte, pieza, accion, estado, cantidad) VALUES ('$num_reclamacion', '$tipo', '$marca', '$modelo', '$chasis', '$cliente', '$proveedor', '$taller', '$corredor', '".$parte[$i]."', '".$pieza[$i]."', '".$accion[$i]."', '".$estado[$i]."', '".$cantidad[$i]."')";
		
				//variable que guarda el resultado de los datos enviados a la DB//
				$resultado = mysqli_query($link, $query);
			}	
		}
		
		mysqli_close($link);
		
//	}
	//else {
		//header('location: ../Login.php');	
	//}
	
	$to      = 'carlos.marte.2408@gmail.com';
	$subject = 'Levantamiento de Daños';
	
	$message = '
		<!DOCTYPE html>
		<html>
		<head>
		<title>Numero de Reclamación</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
		
		<link type="text/css" rel="stylesheet" href="../css/mail.css"/>
		
		</head>
		
		<body style="margin: 0 !important; padding: 0 !important; background-color: #eeeeee;" bgcolor="#eeeeee">
		
			<!-- HIDDEN PREHEADER TEXT -->
			<div style="display: none; font-size: 1px; color: #fefefe; line-height: 1px; font-family: Open Sans, Helvetica, Arial, sans-serif; max-height: 0px; max-width: 0px; opacity: 0; overflow: hidden;">
		
			</div>
		
			<table border="0" cellpadding="0" cellspacing="0" width="100%">
				<tr>
					<td align="center" style="background-color: #eeeeee;" bgcolor="#eeeeee">
						<!--[if (gte mso 9)|(IE)]>
							<table align="center" border="0" cellspacing="0" cellpadding="0" width="600">
								<tr>
									<td align="center" valign="top" width="600">
						<![endif]-->
						<table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width:600px;">
							<tr>
								<td align="center" valign="top" style="font-size:0; padding: 35px;" bgcolor="#044767">
									<!--[if (gte mso 9)|(IE)]>
										<table align="center" border="0" cellspacing="0" cellpadding="0" width="600">
											<tr>
												<td align="left" valign="top" width="300">
										<![endif]-->
									<div style="display:inline-block; max-width:50%; min-width:100px; vertical-align:top; width:100%;">
										<table align="left" border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width:300px;">
											<tr>
												<td align="left" valign="top" style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 36px; font-weight: 800; line-height: 48px;" class="mobile-center">
													<h2 style="font-size: 20px; font-weight: 800; margin: 0; color: #ffffff;">Levantamiento de Daños</h2>
												</td>
											</tr>
										</table>
									</div>
									<!--[if (gte mso 9)|(IE)]>
										</td>
											<td align="right" width="300">
									<![endif]-->
									<div style="display:inline-block; max-width:50%; min-width:100px; vertical-align:top; width:100%;" class="mobile-hide">
										<table align="left" border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width:300px;">
											<tr>
												<td align="right" valign="top" style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 48px; font-weight: 400; line-height: 48px;">
													<table cellspacing="0" cellpadding="0" border="0" align="right">
														<tr>
															<td style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 18px; font-weight: 400;">
																<p style="font-size: 18px; font-weight: 400; margin: 0; color: #ffffff;">Sistema de Notificación&nbsp;</p>
															</td>
															<td style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 18px; font-weight: 400; line-height: 24px;">
																<img src="http://www.freeiconspng.com/uploads/email-icon--100-flat-vol-2-iconset--graphicloads-18.png" width="50" height="50" style="display: block; border: 0px;" alt=""/>
															</td>
														</tr>
													</table>
												</td>
											</tr>
										</table>
									</div>
									<!--[if (gte mso 9)|(IE)]>
												</td>
											</tr>
										</table>
									<![endif]-->
								</td>
							</tr>
							<tr>
								<td align="center" style="padding: 2px 5px 10px 5px; background-color: #ffffff;" bgcolor="#ffffff">
									<!--[if (gte mso 9)|(IE)]>
									<table align="center" border="0" cellspacing="0" cellpadding="0" width="600">
										<tr>
											<td align="center" valign="top" width="600">
									<![endif]-->
									<table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width:600px;">
										<tr>
											<td align="center" style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 16px; font-weight: 400; line-height: 10px; padding-top: 25px;">
												<img src="http://pluspng.com/img-png/png-tick-png-transparent-png-svg-blue-check-mark-512.png" width="100" height="100" style="display: block; border: 0px;" alt="hecho" />
												<h2 style="font-size: 30px; font-weight: 800; line-height: 36px; color: #333333; margin: 0;">
													Se ha completado el formulario de Levantamiento de Daños!
												</h2>
											</td>
										</tr>
										<tr>
											<td align="left" style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 16px; font-weight: 400; line-height: 24px; padding-top: 10px;">
												<p style="font-size: 16px; font-weight: 400; line-height: 24px; color: #777777; text-align:center;">
													A continuación se muestran los detalles de tu reclamación.
												</p>
											</td>
										</tr>
										<tr>
											<td align="left" style="padding-top: 20px;">
												<table cellspacing="0" cellpadding="0" border="0" width="100%">
													<tr>
														<td width="70%" align="left" bgcolor="#eeeeee" style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 16px; font-weight: 800; line-height: 24px; padding: 10px;">
															Número de reclamación #
														</td>
														<td width="30%" align="left" bgcolor="#eeeeee" style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 16px; font-weight: 800; line-height: 24px; padding: 10px;">
															'.$num_reclamacion.'
														</td>
													</tr>
												</table>
											</td>
										</tr>
									</table>
									<!--[if (gte mso 9)|(IE)]>
						</td>
						</tr>
						</table>
						<![endif]-->
								</td>
							</tr>
							<tr>
								<td align="center" height="100%" valign="top" width="100%" style="padding: 0 35px 35px 35px; background-color: #ffffff;" bgcolor="#ffffff">
									<!--[if (gte mso 9)|(IE)]>
						<table align="center" border="0" cellspacing="0" cellpadding="0" width="600">
						<tr>
						<td align="center" valign="top" width="600">
						<![endif]-->
									
									<!--[if (gte mso 9)|(IE)]>
						</td>
						</tr>
						</table>
						<![endif]-->
								</td>
							</tr>
							<tr>
								<td align="center" style=" padding: 0px; background-color: #1b9ba3;" bgcolor="#1b9ba3">
									<!--[if (gte mso 9)|(IE)]>
						<table align="center" border="0" cellspacing="0" cellpadding="0" width="600">
						<tr>
						<td align="center" valign="top" width="600">
						<![endif]-->
									<table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width:600px;">
										<tr>
											<td align="center" style="font-family: Open Sans, Helvetica, Arial, sans-serif; font-size: 16px; font-weight: 400; line-height: 24px; padding-top: 25px;">
												<h2 style="font-size: 18px; font-weight: 800; line-height: 30px; color: #ffffff; margin: 0;">
													Para dar seguimiento a esta reclamación
												</h2>
											</td>
										</tr>
										<tr>
											<td align="center" style="padding: 15px 0 5px 0;">
												<table border="0" cellspacing="0" cellpadding="0">
													<tr>
														<td align="center" style="border-radius: 5px;" bgcolor="#66b3b7">
															<a href="http://qsgsoluions.com/demo/f5p/reclamaciones.php" target="_blank" style="font-size: 18px; font-family: Open Sans, Helvetica, Arial, sans-serif; color: #ffffff; text-decoration: none; border-radius: 5px; background-color: #66b3b7; padding: 15px 30px; border: 1px solid #66b3b7; display: block;">has clic aquí</a>
														</td>
													</tr>
												</table>
											</td>
										</tr>
									</table>
									<!--[if (gte mso 9)|(IE)]>
						</td>
						</tr>
						</table>
						<![endif]-->
								</td>
							</tr>
							
						</table>
						<![endif]-->
								</td>
							</tr>
						</table>
						<!--[if (gte mso 9)|(IE)]>
				</td>
				</tr>
				</table>
				<![endif]-->
					</td>
				</tr>
			</table>
		
		</body>
		</html>
	';
	
	// To send HTML mail, the Content-type header must be set
	$headers[] = 'MIME-Version: 1.0';
	$headers[] = 'Content-type: text/html; charset=iso-8859-1';
	
	// Additional headers
	$headers[] = 'To: Carlos Marte <"'.$to.'">';
	$headers[] = 'From: Sistema de Notificación <no-replay@example.com>';
	$headers[] = 'X-Mailer: PHP/' . phpversion();
	
	mail($to, $subject, $message, implode("\r\n", $headers));
//}
?>

<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
    <meta name="HandheldFriendly" content="true" />
    <title>Gracias!!!</title>
    <link href='https://fonts.googleapis.com/css?family=Didact%20Gothic:light,lightitalic,normal,italic,bold,bolditalic' rel='stylesheet' type='text/css'>
    
    <style type="text/css">
      @import url(https://fonts.googleapis.com/css?family=Didact%20Gothic:light,lightitalic,normal,italic,bold,bolditalic);
      * {
        -moz-box-sizing:border-box;
        -webkit-box-sizing:border-box;
        box-sizing:border-box;
        *behavior:url(js/boxsizing.htc);
      }
      html, body { width:100%; margin:0px; padding:0px; }
      body {
        
        background-color:#4696e5;
      	background-size: cover;
       	background-position: 50% 50%;
        font-family: 'Didact Gothic', sans-serif;
        font-size: 18px;
        color: #555;
        text-align:center;
      }
      .form-all {
        background: url('') #fff;
        background-repeat: repeat;
        background-attachment: scroll;
        background-position: center top;
        background-size: auto;
        
        width: 100%;
        max-width: 550px;
        margin: 36px auto;
        padding: 35px 29px ;
        -webkit-box-shadow: 0 4px 4px -1px rgba(0,0,0,0.1);
        box-shadow: 0 4px 4px -1px rgba(0,0,0,0.1);
      }

      #footer {
        text-align: left;
        margin: -35px auto 0;
        font-size: 14px;
        width: 550px;
      }

      #footer > div {
        box-shadow: 0 4px 4px -1px rgba(0,0,0,0.1);
        background-color: #fff;
        padding: 12px 15px;
        overflow: hidden;
      }

      #footer > div > div { padding: 10px 0 10px 5px }

      .thankYouPage-footerJFLink span { display: none }

      @media screen and (max-width: 550px), screen and (max-device-width: 768px) and (orientation: portrait), screen and (max-device-width: 415px) and (orientation: landscape) {
        body {
      		background-color:#4696e5;
       		background-size: cover;
       		font-family: 'Open Sans',sans-serif;
   
        }
        .form-all {
          margin: 12px 3%;
          border: 0;
          -webkit-box-shadow: none;
          box-shadow: none;
          width: 94%;
          max-width: initial;
        }

        .thankYouPage-footerJFLink img { display: none }
        .thankYouPage-footerJFLink span { display: inline-block }

        #footer {
          width: 94%;
          margin-top: 0;
        }

        #footer > div > div { padding: 3px 0 0 5px; font-size: 12px; }

        #footer > div > div span { display: block }
        #footer > div > div span.footer-dash { display: none }
      }
      @media print {
       body {
    	background-color:#4696e5;
        background-size: cover;
        font-family: 'Open Sans',sans-serif;
        background-position: 50% 50%;
       }

       .form-all {
        margin:0 auto;
        max-width: 100%;
        box-shadow: none;
        background:white;
        float:none;
        width: 550px;
       } 
       img {
        max-width: 100% !important;
        page-break-inside: avoid;
       }

      }
    </style>
    <style type="text/css">
    
    </style>
    <!-- <link href="css/print-new.css" rel="stylesheet" type="text/css" media="print"> -->
  </head>
  <body class="thankyou">
    <div id="stage" class="form-all">
    	<p style="text-align:center;">
        	<img src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/bd/Checkmark_green.svg/2000px-Checkmark_green.svg.png" alt="" width="128" height="128" />
       	</p>
       	<div style="text-align:center;">
        	<h1 style="text-align: center;">Gracias!</h1>
            <p style="text-align: center;">Tu número de reclamación es <b><?php echo $num_reclamacion ?></b>. Un correo con los detalles ha sido enviado al analista.</p>
      	</div>
  	</div>
    <div id="footer" class="form-footer">
    	<div>
      		<a href="../reclamaciones.php" target="_blank" style="text-decoration: none; color: #fff; background-color: #f98e03; border-radius: 3px; float: right; padding: 9px 15px; font-size: 15px; display: inline-block; vertical-align: middle;" onClick="closeCurrentWindow();">Volver atrás</a>
      
    	</div>
    </div>
  </body>
  <script type="text/javascript">
    if (window.parent !== window) {
      var stageMarginTop = ($('stage')) ? parseInt($('stage').getStyle('marginTop')) : 0;
      var height = $$('body').first().getHeight() + stageMarginTop;
      window.parent.postMessage('setHeight:' + height, '*');
    }
  </script>
  <script>
  	function closeCurrentWindow() {
  		window.close();
	}
  </script>
</html>

