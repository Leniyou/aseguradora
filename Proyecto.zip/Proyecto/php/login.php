<?php

if(isset($_POST['entrar'])){
	//archivo con la conexion a la DB//
	require_once dirname(__FILE__) . '\Conexion_DB.php';
	
	//Mostrar caracteres especiales en Español "ñ" por ejemplo//	
	mysqli_set_charset($link, "utf8");

	$loginname = mysqli_real_escape_string($link, $_POST['usuario']);
	$passwd = mysqli_real_escape_string($link, $_POST['contrasena']);
		
	$result = $link->query("SELECT * FROM usuarios WHERE username='$loginname'");
	
	$row = $result->fetch_array(MYSQLI_BOTH);
	
	if(password_verify($passwd, $row['password'])){
		
		session_start();

		// muestra nombre completo de quien ha iniciado sesion //
		echo "Has iniciado sesión correctamente!";
		$_SESSION['empleado_nap'] = $row['nombre']." ".$row['apellido'];
		$_SESSION['userID'] = $row['userID'];
		
		$userid = $row['admin'];
					  
		if ($userid == 'soc'){
			header('location: ../SOC/Index_Soc.php');
		}
		else {
			header('location: ../Index.php');
		}	
	}
	else {
		session_start();
			echo "<script type='text/javascript'>";
				echo "alert('Error de inicio de sesion, favor verificar el NOMBRE DE USUARIO o la CONTRASEÑA');";
				echo "window.history.go(-1);";
			echo "</script>";
	}
}
else {
	header('location: ../Login.php');	
}
?>