<?php
	//Variables para la conexion a la DB//
	$DB_NAME = "u595149034_f5p";
	$DB_USER = "u595149034_root";
	$DB_PASS = "hlg&3BtUC`Qej!";
	$DB_HOST = "sql121.main-hosting.eu.";
	
	//Variable "link" que guarda los parametros para la conexion al localhost//
	$link= mysqli_connect("$DB_HOST", "$DB_USER", "$DB_PASS") or die ("No se pudo conectar a la base de datos");
	
	//Variable para seleccionar la DB//	
	mysqli_select_db($link, "$DB_NAME") or die ("No connection");
	
	//Mostrar caracteres especiales en Español "ñ" por ejemplo//	
	mysqli_set_charset($link, "utf8");
?>