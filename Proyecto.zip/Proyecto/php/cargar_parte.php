<?php
/*
	//Para saber si se ha iniciado sesion//
	session_start();
	
	if(isset($_SESSION['empleado_nap'])){ */
	
	//archivo con la conexion a la DB//
	include('Conexion_DB.php');
			
	$db_parte = "SELECT * FROM partes ORDER BY id_partes ASC";
	$query_parte = mysqli_query($link, $db_parte);
			
			
	echo  '<option value="" selected>Parte Afectada...</option>';
			
	while ($row = mysqli_fetch_array($query_parte)) {
		$parte = $row['parte'];
							
		echo '<option value="'.$parte.'">'.$parte.'</option>';
                
	}
				
	//Cierra la conexion a la DB//
	mysqli_close($link);
	
	/*
	else {
		header('location: ../Login.php');	
	}
	*/
?>